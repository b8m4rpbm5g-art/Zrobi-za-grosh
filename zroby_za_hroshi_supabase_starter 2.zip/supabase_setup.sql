-- Run in Supabase SQL Editor only if you need to re-apply the protection.
alter table public.tasks enable row level security;
alter table public.tgr_ledger enable row level security;
revoke all on public.tasks from anon, authenticated;
revoke all on public.tgr_ledger from anon, authenticated;
-- No browser policies are created intentionally. Server functions use the
-- service-role key stored only in Netlify environment variables.
select tablename, rowsecurity from pg_tables
where schemaname='public' and tablename in ('tasks','tgr_ledger') order by tablename;
