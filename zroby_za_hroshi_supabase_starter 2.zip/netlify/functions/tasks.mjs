import crypto from "node:crypto";
import { createClient } from "@supabase/supabase-js";
function verify(initData, token){
 if(!initData||!token)return null;const p=new URLSearchParams(initData),hash=p.get("hash"),date=Number(p.get("auth_date"));
 if(!hash||!date||Math.abs(Date.now()/1000-date)>86400)return null;p.delete("hash");
 const check=[...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join("\\n");
 const secret=crypto.createHmac("sha256","WebAppData").update(token).digest();
 const expected=crypto.createHmac("sha256",secret).update(check).digest("hex");
 const a=Buffer.from(expected,"hex"),b=Buffer.from(hash,"hex");if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;
 try{const u=JSON.parse(p.get("user")||"{}");return Number.isSafeInteger(u.id)?u.id:null}catch{return null}
}
export default async req=>{
 const out=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type,X-Telegram-Init-Data","Access-Control-Allow-Methods":"GET,POST,OPTIONS"}});
 if(req.method==="OPTIONS")return out({},204);
 const {SUPABASE_URL:url,SUPABASE_SERVICE_ROLE_KEY:key,TELEGRAM_BOT_TOKEN:token}=process.env;
 if(!url||!key||!token)return out({error:"На Netlify не налаштовані серверні змінні."},500);
 const uid=verify(req.headers.get("x-telegram-init-data")||"",token);if(!uid)return out({error:"Не вдалося перевірити Telegram. Відкрий Mini App через бота."},401);
 const db=createClient(url,key,{auth:{persistSession:false}});
 if(req.method==="GET"){const {data,error}=await db.from("tasks").select("id,title,description,reward_tgr,status,created_at").order("created_at",{ascending:false}).limit(100);if(error)return out({error:"Не вдалося прочитати завдання."},500);return out({tasks:data})}
 if(req.method==="POST"){let x;try{x=await req.json()}catch{return out({error:"Некоректні дані."},400)}
 const title=typeof x.title==="string"?x.title.trim():"",description=typeof x.description==="string"?x.description.trim():"",reward=Number(x.reward_tgr);
 if(!title||title.length>100||description.length>1000||!Number.isSafeInteger(reward)||reward<0||reward>1000000)return out({error:"Перевір назву, опис і винагороду."},400);
 const {data,error}=await db.from("tasks").insert({title,description,reward_tgr:reward,status:"open",creator_telegram_id:uid}).select("id,title,description,reward_tgr,status,created_at").single();if(error)return out({error:"Не вдалося зберегти завдання. Перевір SQL-схему."},500);return out({task:data},201)}
 return out({error:"Метод не підтримується."},405)
};